from neuropulse.utils import additon

def main():
    result = additon(2, 4)
    print(result)

if __name__ == "__main__":
    main()